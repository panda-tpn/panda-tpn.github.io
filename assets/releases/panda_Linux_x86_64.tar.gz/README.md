# PåNĐA

a tool for state estimation, prognosis and diagnosability of time Petri nets

## GoReleaser

use `goreleaser release --snapshot --clean` for generating snapshot
