# PåNĐA

A tool for state estimation, prognosis and diagnosability of time Petri nets,
see <https://panda-tpn.github.io/>.
